def shrug_smile():
    print("¯\_(ツ)_/¯")
def ktulhu_smile():
    print("{:€")
def happy_smile():
    print("(͡° ͜ʖ ͡°)")


shrug_smile()
ktulhu_smile()
happy_smile()

