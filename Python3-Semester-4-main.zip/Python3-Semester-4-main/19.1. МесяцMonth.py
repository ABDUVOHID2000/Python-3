def monthname(a,b):
    if a == 1:
        if (b == "ru"):
            print("Январь")
        elif(b == "en"):
            print("January")
    elif a == 2:
        if (b == "ru"):
            print("Фебраль")
        elif(b == "en"):
            print("February")
    elif a == 3:
        if (b == "ru"):
            print("Март")
        elif(b == "en"):
            print("March")
    elif a == 4:
        if (b == "ru"):
            print("Апрель")
        elif(b == "en"):
            print("April")
    elif a == 5:
        if (b == "ru"):
            print("Май")
        elif(b == "en"):
            print("May")
    elif a == 6:
        if (b == "ru"):
            print("июнь")
        elif(b == "en"):
            print("June")
    elif a == 7:
        if (b == "ru"):
            print("июль")
        elif(b == "en"):
            print("July")
    elif a == 8:
        if (b == "ru"):
            print("Августь")
        elif(b == "en"):
            print("August")
    elif a == 9:
        if (b == "ru"):
            print("сентябрь")
        elif(b == "en"):
            print("September")
    elif a == 10:
        if (b == "ru"):
            print("Октябрь")
        elif(b == "en"):
            print("October")
    elif a == 11:
        if (b == "ru"):
            print("Ноябрь")
        elif(b == "en"):
            print("November")
    elif a == 12:
        if (b == "ru"):
            print("Декабрь")
        elif(b == "en"):
            print("December")
    
monthname(int(input()), input())