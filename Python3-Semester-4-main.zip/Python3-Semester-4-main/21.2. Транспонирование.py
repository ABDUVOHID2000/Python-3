def transpose(matrix):
    return[list(x) for x in zip(*maxrix)]
 
maxrix = [[1,2,3], [4,5,6], [7,8,9]]
 
print(transpose(maxrix))
for line in maxrix:
    print(*line)
