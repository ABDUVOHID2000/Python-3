def defractalize(fractal):
  return [x for x in fractal if x is not fractal]

fractal = [2, 5]
fractal.append(fractal)
fractal.append(3)
defractalize(fractal)
print(fractal)
