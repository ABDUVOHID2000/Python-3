black = []
white = []
white.extend([black, black])
black.extend([white, white, white])
wb_tree = black